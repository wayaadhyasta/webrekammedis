<?php

session_start();

if (!isset($_SESSION['ssLoginRM'])) {
  header("location: ../otentikasi/index.php");
  exit();
}


require "../config.php";

// tambah obat baru 
if(isset($_POST['simpan'])){
    $nama = trim(htmlspecialchars($_POST['nama']));
    $kegunaan = trim(htmlspecialchars($_POST['kegunaan']));

    mysqli_query($koneksi,"INSERT INTO tbl_obat VALUES(null,'$nama','$kegunaan')");
    
    header('location: tambah-obat.php?msg=added');
    return;

}

// hapus obat
if(@$_GET['aksi'] == 'hapus-obat'){
    $id = $_GET['id'];
    mysqli_query($koneksi,"DELETE FROM tbl_obat WHERE id = $id");
    header('location: index.php?msg=deleted');
    return;
}

// update obat 
if(isset($_POST['update'])){
    $id = trim(htmlspecialchars($_POST['id']));
    $nama = trim(htmlspecialchars($_POST['nama']));
    $kegunaan = trim(htmlspecialchars($_POST['kegunaan']));

    mysqli_query($koneksi,"UPDATE  tbl_obat SET nama = '$nama', kegunaan = '$kegunaan' WHERE id = $id");
    
    header('location: index.php?msg=updated');
    return;

}

// ganti password 

// if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus-user' && isset($_GET['id']) && isset($_GET['gambar'])) {
//     $id = intval($_GET['id']);
//     $gbr = htmlspecialchars($_GET['gambar']);
//     // Lanjutkan proses penghapusan...
// } else {
//     echo "<script>
//             alert('Parameter tidak lengkap!');
//             window.location.href = 'index.php';
//           </script>";
// }


?>
<!-- if (isset($_POST['Update'])) {
    $id = $_POST['id'];
    $userLama = trim(htmlspecialchars($_POST['usernameLama']));
    $username = trim(htmlspecialchars($_POST['username']));
    $nama = trim(htmlspecialchars($_POST['fullname']));
    $jabatan = $_POST['jabatan'];
    $alamat = trim(htmlspecialchars($_POST['alamat']));
    $gambar = htmlspecialchars($_FILES['gambar']['name']);
    $gbrLama = htmlspecialchars($_POST['gbrLama']);
   

    $cekUsername = mysqli_query($koneksi, "SELECT * FROM 
    tbl_user WHERE username = '$username'");
    if (mysqli_num_rows($cekUsername)) {
        echo "<script>
                    alert('username sudah terpakai, user baru gagal di registrasi !');
                    window.location = 'tambah-user.php'
        </script>";
        return;
    }

    if ($password !== $password2){ // menggecek password dengan konfrimasi password
        echo "<script>
                    alert('password tidak sesuai, user baru gagal di registrasi !');
                    window.location = 'tambah-user.php';
        </script>";
        return;
    }

    $pass = password_hash($password, PASSWORD_DEFAULT); 

    if($gambar !== null){
        $url = 'tambah-user.php';
        $gambar = uploadGbr($url);
    }else{
        $gambar = 'user.png';
    }

    mysqli_query($koneksi, "INSERT INTO tbl_user VALUES (null,
    '$username','$nama','$pass','$jabatan','$alamat','$gambar')");


    echo "<script>
                alert('User baru berhasil di registrasi !');
                window.location = 'tambah-user.php';
    </script>";
    return;

} -->