</div>
</div>
<script src="<?= $main_url ?>asset/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.2.1/dist/chart.umd.min.js" 
    integrity="sha384-gdQErvCNWvHQZj6XZM0dNsAoY4V+j5P1XDpNkcM3HJG1Yx04eqLHk7+4VBOCHOG" 
    crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/2.1.8/js/dataTables.js"></script>

<?php

$bln_ini = date('n');
$thn_ini = date('Y');
$list_data = [];

for ($i = 1; $i <= $bln_ini; $i++) {
    $start_date = "$thn_ini-$i-01";
    $end_date = date('Y-m-t', strtotime($start_date));
    $rm_yearly = mysqli_query($koneksi, "SELECT * FROM tbl_rekammedis WHERE tgl_rm BETWEEN '$start_date' AND '$end_date'");
    $list_data[] = mysqli_num_rows($rm_yearly);
}
?>

<script>
    /* globals Chart:false */

    let blnSkrng = <?= $bln_ini ?>;

    let nmBln = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

    let listBln = [];
    for (let i = 0; i < blnSkrng; i++) {
        listBln.push(nmBln[i]);
    }

(() => {
  'use strict';

  // Graphs
  const ctx = document.getElementById('myChart');
  // eslint-disable-next-line no-unused-vars
  const myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: listBln,
        datasets: [{
            data: <?= json_encode($list_data) ?>,
            lineTension: 0,
            backgroundColor: 'transparent',
            borderColor: '#007bff',
            borderWidth: 4,
            pointBackgroundColor: '#007bff'
      }]
    },
    options: {
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          boxPadding: 3
        }
      }
    }
  });
})();

</script>

<script>
    // Inisialisasi DataTable dengan ID tabel yang benar
    let table = new DataTable('#myTable');
</script>
</body>
</html>
