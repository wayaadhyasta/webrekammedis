<?php

session_start();

if (!isset($_SESSION['ssLoginRM'])) {
  header("location: ../index.php");
  exit();
}

require "../config.php";

$title = "Ganti Password - Rekam Medis";

require "../template/header.php";
require "../template/navbar.php";
require "../template/sidebar.php";

?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 min-vh-100">
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Ganti Password</h1>
  </div>

  <div class="card shadow-sm">
    <div class="card-body">
      <form action="../user/proses-user.php" method="post" class="needs-validation" novalidate>
        <div class="form-group mb-3">
          <label for="oldPass" class="form-label">Password Lama</label>
          <input type="password" name="oldPass" id="oldPass" class="form-control" placeholder="Masukkan password lama" autocomplete="off" required>
          <div class="invalid-feedback">
            Password lama wajib diisi.
          </div>
        </div>
        <div class="form-group mb-3">
          <label for="newPass" class="form-label">Password Baru</label>
          <input type="password" name="newPass" id="newPass" class="form-control" placeholder="Masukkan password baru" autocomplete="off" required>
          <div class="invalid-feedback">
            Password baru wajib diisi.
          </div>
        </div>
        <div class="form-group mb-3">
          <label for="confPass" class="form-label">Konfirmasi Password</label>
          <input type="password" name="confPass" id="confPass" class="form-control" placeholder="Masukkan kembali password baru" autocomplete="off" required>
          <div class="invalid-feedback">
            Konfirmasi password wajib diisi.
          </div>
        </div>
        <div class="d-flex justify-content-between">
          <button type="reset" class="btn btn-danger btn-sm">
            <i class="bi bi-x-lg align-top"></i> Reset
          </button>
          <button type="submit" name="ganti-password" class="btn btn-primary btn-sm">
            <i class="bi bi-save align-top"></i> Simpan
          </button>
        </div>
      </form>
    </div>
  </div>
</main>

<?php

require "../template/footer.php";

?>

<script>
  // Bootstrap form validation
  (function () {
    'use strict';
    const forms = document.querySelectorAll('.needs-validation');
    Array.prototype.slice.call(forms).forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  })();
</script>
