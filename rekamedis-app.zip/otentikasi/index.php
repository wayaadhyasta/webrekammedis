<?php

session_start();

if (isset($_SESSION['ssLoginRM'])) {
  header("location: ../index.php");
  exit();
}

require "../config.php";

?>

<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head>
    <script src="../asset/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Halaman Login Rekam Medis">
    <meta name="author" content="Adhyasta Adwaya Alkarim">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Login - Rekam Medis</title>

    <link rel="icon" type="image/x-icon" href="<?=$main_url?>/asset/gambar/app-icon.png">
    <link rel="stylesheet" href="<?=$main_url?>/asset/dist/css/bootstrap.min.css">

    <style>
      body {
        background: linear-gradient(to bottom, #6a11cb, #2575fc);
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        color: #fff;
        font-family: 'Poppins', sans-serif;
      }
      .form-signin {
        max-width: 400px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        padding: 30px;
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        animation: fadeIn 1s ease-in-out;
      }
      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
      .form-floating input {
        background: rgba(255, 255, 255, 0.2);
        border: 1px solid rgba(255, 255, 255, 0.4);
        color: #fff;
      }
      .form-floating input:focus {
        border-color: #6a11cb;
        background: rgba(255, 255, 255, 0.3);
        box-shadow: 0 0 10px #6a11cb;
      }
      .btn-primary {
        background-color: #6a11cb;
        border: none;
        transition: background 0.3s;
      }
      .btn-primary:hover {
        background-color: #4c0fcf;
      }
      .form-signin img {
        border-radius: 50%;
        margin-bottom: 20px;
      }
      .text-body-secondary {
        color: rgba(255, 255, 255, 0.6) !important;
      }
    </style>
  </head>
  <body>
  <main class="form-signin">
    <form action="proses-login.php" method="post">
        <h1 class="h3 mb-3 fw-bold">Selamat Datang Di Klinik 24 JAM Yogyakarta</h1>
        <p class="mb-4">Silakan masuk untuk mengakses sistem.</p>

        <div class="form-floating mb-3">
            <input type="text" class="form-control" id="floatingInput" placeholder="masukan username admin" name="username" required>
            <label for="floatingInput">Username ketik admin</label>
        </div>
        <div class="form-floating mb-4">
            <input type="password" class="form-control" id="floatingPassword" placeholder="1234" name="password" required>
            <label for="floatingPassword">Password ketik 1234</label>
        </div>

        <button class="btn btn-primary w-100 py-2" type="submit" name="login">Sign in</button>
        <p class="mt-4 text-body-secondary">© 2024 Adhyasta Adwaya Alkarim</p>
    </form>
</main>
<script src="<?=$main_url?>/asset/dist/js/bootstrap.bundle.min.js"></script>

