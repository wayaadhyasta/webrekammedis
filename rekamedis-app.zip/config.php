<?php

date_default_timezone_set('Asia/Jakarta');

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'db_rekamedis'; 

$koneksi = mysqli_connect($host,$user,$pass,$dbname);

// if (!$koneksi){
//     die('koneksi gagal');
// }else{
//     echo "koneksi berhasil";
// }

$main_url = "http://localhost/rekamedis-app/";

function uploadGbr($url){
    $namafile = $_FILES['gambar']['name'];
    $ukuran = $_FILES['gambar']['size'];
    $tmp = $_FILES['gambar']['tmp_name'];

    $ekstensiValid = ['jpg','jpeg','png','gif'];

    $ekstensiValie = explode('.',$namafile);
    $ekstensiValie = strtolower(end($ekstensiValie));

    if(!in_array($ekstensiValie, $ekstensiValid)){
        echo "<script>
            alert('input user gagal, file yang anda uplod bukan gambar');
            window.location = '$url';
        </script>";
        die();
    }

    if($ukuran > 1000000){
        echo "<script>
            alert('gambar terlalu besar, max ukuran gambar 1 mb');
            window.location = '$url';
        </script>";
    die();
    }

    $nameFileBaru = time().'-'. $namafile;

    move_uploaded_file($tmp, '../asset/gambar/'.$nameFileBaru);

    return $nameFileBaru;
}

function in_date($tgl){
    $dd = substr($tgl, 8, 2);
    $mm = substr($tgl, 5, 2);
    $yyyy = substr($tgl, 0, 4);

    return $dd . "-" . $mm . "-" . $yyyy;
}

function htUmur($tgl_lahir){
    $tglLahir = new DateTime($tgl_lahir);
    $hariini = new DateTime("today");

    $umur = $hariini->diff($tglLahir)->y;

    return $umur . "tahun";
}

function htgUmur($tgl_lahir){
    $tgl_lahir = new DateTime($tgl_lahir);
    $hariini = new DateTime("today");
    $umur = $hariini->diff($tgl_lahir)->y;
    
    return $umur. "tahun";
}

 ?>