<?php

session_start();

if (!isset($_SESSION['ssLoginRM'])) {
  header("location:otentikasi/index.php");
  exit();
}

require "config.php";

$title = "Dashboard - Rekam Medis";

require "template/header.php";
require "template/navbar.php";
require "template/sidebar.php";

?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 min-vh-100">
  <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Data Kunjungan Pasien</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
      <div class="btn-group me-2">
        <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle d-flex align-items-center gap-1">
          <svg class="bi"><use xlink:href="#calendar3"/></svg>
          Tahun ini
        </button>
      </div>
    </div>
  </div>

  <div class="row">
    <!-- Card for Total Kunjungan -->
    <div class="col-lg-4 col-md-6 mb-4">
      <div class="card shadow-sm h-100">
        <div class="card-body d-flex flex-column justify-content-center align-items-center">
          <h5 class="card-title">Total Kunjungan Pasien</h5>
          <p class="display-4">120</p>
          <a href="#" class="btn btn-primary">Lihat Detail</a>
        </div>
      </div>
    </div>

    <!-- Card for Kunjungan Perbulan -->
    <div class="col-lg-4 col-md-6 mb-4">
      <div class="card shadow-sm h-100">
        <div class="card-body d-flex flex-column justify-content-center align-items-center">
          <h5 class="card-title">Kunjungan Perbulan</h5>
          <p class="display-4">10</p>
          <a href="#" class="btn btn-primary">Lihat Detail</a>
        </div>
      </div>
    </div>

    <!-- Card for Pasien Baru -->
    <div class="col-lg-4 col-md-6 mb-4">
      <div class="card shadow-sm h-100">
        <div class="card-body d-flex flex-column justify-content-center align-items-center">
          <h5 class="card-title">Pasien Baru</h5>
          <p class="display-4">30</p>
          <a href="#" class="btn btn-primary">Lihat Detail</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Chart.js - Grafik Kunjungan Pasien -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <h5 class="card-title">Grafik Kunjungan Pasien</h5>
      <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas>
    </div>
  </div>
</main>

<?php

require "template/footer.php";

?>

<!-- Script Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// Membuat grafik dengan Chart.js
const ctx = document.getElementById('myChart').getContext('2d');
const myChart = new Chart(ctx, {
  type: 'bar', // Jenis grafik batang
  data: {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], // Label bulan
    datasets: [{
      label: 'Kunjungan Pasien',
      data: [12, 19, 3, 5, 2, 3, 7, 11, 8, 13, 9, 4], // Data kunjungan pasien per bulan
      borderWidth: 1, // Lebar border grafik
      backgroundColor: 'rgba(54, 162, 235, 0.2)', // Warna latar belakang batang
      borderColor: 'rgba(54, 162, 235, 1)', // Warna border batang
    }]
  },
  options: {
    scales: {
      y: {
        beginAtZero: true, // Mulai sumbu Y dari angka 0
      }
    }
  }
});
</script>
